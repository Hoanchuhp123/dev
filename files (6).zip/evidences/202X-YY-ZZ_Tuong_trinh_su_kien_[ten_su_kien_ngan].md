# TƯỜNG TRÌNH SỰ KIỆN: [Tên sự kiện ngắn gọn, ví dụ: Bắt giữ trái pháp luật ngày 31/10/2023]

> **Mục đích:** Ghi nhận chi tiết một sự kiện/tình tiết quan trọng trong vụ án để làm căn cứ pháp lý, bổ sung hồ sơ, đối chiếu với các bên liên quan.

---

## 1. Thông tin chung về sự kiện

- **Thời gian xảy ra:**  
- **Địa điểm:**  
- **Các bên liên quan:**  
  - Người bị ảnh hưởng/chứng kiến:  
  - Đối tượng thực hiện hành vi:  
  - Nhân chứng (nếu có):  

---

## 2. Diễn biến sự kiện

- **Trình tự diễn ra:**  
  - (Ghi rõ từng bước, từng hành động)
- **Hành vi cụ thể của từng bên:**  
- **Phản ứng, lời nói, hành động liên quan:**  

---

## 3. Hậu quả và tác động

- **Tác động đến người bị hại:**  
- **Thiệt hại vật chất/tinh thần:**  
- **Ảnh hưởng tới quá trình tố tụng:**  

---

## 4. Bằng chứng đính kèm

- **Ghi âm/video/ảnh:**  
  - (Liệt kê tên file, định dạng, vị trí lưu)
- **Tài liệu, giấy tờ liên quan:**  
  - (Liệt kê bản sao, biên bản, giấy xác nhận, nếu có)
- **Nhân chứng (liên hệ):**  
  - (Tên, số điện thoại, địa chỉ nếu cần)

---

## 5. Yêu cầu/ký kiến đề xuất

- (Nêu rõ yêu cầu xác minh, điều tra, bảo vệ quyền lợi, hoặc các ý kiến đề xuất cụ thể)

---

## 6. Cam đoan

Tôi xin cam đoan những điều tường trình trên là đúng sự thật và chịu hoàn toàn trách nhiệm trước pháp luật về nội dung này.

**Người tường trình:**  
(Ký, ghi rõ họ tên)  
Ngày … tháng … năm …  

---

> **Lưu ý:**  
Bổ sung hoặc cập nhật tường trình nếu phát hiện thêm tình tiết mới, nhân chứng hoặc bằng chứng liên quan!